﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFramework
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //create the instance
        Training_24Oct18_PuneEntities dbContext = null;

      

        public MainWindow()
        {
            InitializeComponent();

            dbContext = new Training_24Oct18_PuneEntities();
        }

        public void PopulateUI()
        {
            List<Product> prods = dbContext.Products.ToList(); //using LINQ
            //var res = prods.Select(s => s.Price > 4000);
           

            dgProd.ItemsSource = prods;
            cmdName.ItemsSource = prods;
            cmdName.DisplayMemberPath = "Name";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Product prod = new Product();
            List<Product> prods = dbContext.Products.ToList();
            //writing code to get data from controls & set to properties of product
            prod.Name = cmdName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(dpDOB.Text);

            dbContext.Products.Add(prod);
            dbContext.SaveChanges();

            //var res = from s in prods select s.Id;
            var res = prods.Select(s => s.Id);
            var res1 = (res.Max() + 1).ToString();

            MessageBox.Show("ID: "+res1+"\nInserted!");
            PopulateUI();
        }

        int id;

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            id = ((Product)cmdName.SelectedItem).Id;
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("please click first on edit");
            //Product p = (Product)cmdName.SelectedItem;
            //writing code to get data from controls & set to properties of product
            Product prod = dbContext.Products.Single(p => p.Id == id);
            prod.Name = cmdName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(dpDOB.Text);
            dbContext.SaveChanges();
            MessageBox.Show("Updated!");
            PopulateUI();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //used for combo box and textbox
            //int id = ((Product)cmdName.SelectedItem).Id;
            //Product prod = dbContext.Products.Single(p => p.Id == id);

            // used only for combo box
            Product prod = (Product)cmdName.SelectedItem;

            dbContext.Products.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted!");
            PopulateUI();
        }
        

       

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            cmdName.Text = string.Empty;
            txtPrice.Text = string.Empty;
            dpDOB.Text = string.Empty;
            PopulateUI();
        }
        

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            List<Product> prods = dbContext.Products.ToList(); //using LINQ
            //var res = prods.Where(s => s.Price > 4000);
            //var res = prods.Where(s => s.Name.StartsWith("P"));
            //var res = prods.Where(s => s.Price < 4000 & s.Price >1000);
            //var res = prods.Where(s => s.ExpDate.Value.Year >= (DateTime.Now.Year + 2));
            var res = prods.Where(s => s.ExpDate.Value.Date >= (DateTime.Now.Date));
            dgProd.ItemsSource = res;
            cmdName.ItemsSource = res;
            cmdName.DisplayMemberPath = "Name";
        }
        
    }
}
